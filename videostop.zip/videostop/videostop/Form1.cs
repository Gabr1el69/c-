﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Media;

namespace videostop
{
    public partial class Form1 : Form
    {
        private int pokusy = 12; // Počet pokusů
        private SoundPlayer konec; 

        public Form1()
        {
            InitializeComponent();
            konec = new SoundPlayer("W.wav");

        }

        private void button1_Click(object sender, EventArgs e)
        {

            timer1.Start();
            timer2.Start();
            timer3.Start();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (pokusy > 0)
            {
                pokusy--; 
                label4.Text = "zbývající pokusy: " + pokusy; 
                timer1.Stop();
                timer2.Stop();
                timer3.Stop();
            }
            if (pokusy == 0)
            {
                
                timer1.Stop();
                timer2.Stop();
                timer3.Stop();
                konec.Play(); // Přehrát zvuk
                MessageBox.Show("KONEC");
                Form2 form2 = new Form2();
                form2.Show();
                
            }
        }
        private void tocka1(object sender, EventArgs e)
        {
            int cislo1 = 0;
            Random nahoda = new Random();
            label1.Text = nahoda.Next(1, 7).ToString();
            label1.Text = cislo1.ToString();
            return;
            
        }
        private void tocka2(object sender, EventArgs e)
        {
            int cislo2 = 0;
            Random nahoda = new Random();
            label2.Text = nahoda.Next(1, 7).ToString();
            label1.Text = cislo2.ToString();
            return;
        }
        private void tocka3(object sender, EventArgs e)
        {
            int cislo3 = 0;
            Random nahoda = new Random();
            label3.Text = nahoda.Next(1, 7).ToString();
            label1.Text = cislo3.ToString();
            return;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.DifficultySelected += HandleDifficultySelected;
            form3.Show();
        }
        private void HandleDifficultySelected(int difficulty)
        {
            switch (difficulty)
            {
                case 1: // Lehká obtížnost
                    timer1.Interval = 1800;
                    timer2.Interval = 1500;
                    timer3.Interval = 1200;
                    break;
                case 2: // Střední obtížnost
                    timer1.Interval = 500;
                    timer2.Interval = 800;
                    timer3.Interval = 600;
                    break;
                case 3: // Těžká obtížnost
                    timer1.Interval = 200;
                    timer2.Interval = 120;
                    timer3.Interval = 80;
                    break;
                
                    
            }

           

        }
}
}
